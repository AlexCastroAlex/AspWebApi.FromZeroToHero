﻿namespace BookStore.Api.DTO
{
    public class AuthorDto
    {
        public required string FirstName { get; init; }
        public required string LastName { get; init; }
    }
}
